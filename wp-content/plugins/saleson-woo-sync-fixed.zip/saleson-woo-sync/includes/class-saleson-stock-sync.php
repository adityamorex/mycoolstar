<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Cron-driven pull of SalesOn stock/rate data into wp_saleson_stock_cache,
 * insert-only seeding of wp_saleson_product_map, and push of the cached
 * stock + RETAIL CUSTOMER rate onto already-matched WooCommerce products.
 *
 * Numeric SalesOn product id source (this matters for the Matcher/Pricing
 * work happening in parallel): confirmed in Phase 0 (see
 * phase0/findings.md, "Bulk pulls (rate-list / low-stock-summary)") that
 * NEITHER reports/rate-list NOR reports/low-stock-summary expose a numeric
 * id - only `name` / `product_code`. `GET products?with_unit=false` DOES
 * return the real numeric `id` for the entire catalog in a single,
 * non-paginated call (898/898 products in one shot, confirmed against
 * phase0/logs/saleson_products_full.json - it also matches the dashboard's
 * product_count and the rate-list total exactly). So that endpoint is used
 * here purely as the id/lookup catalog: we build a normalized-name => id
 * map from it, then resolve every reports/rate-list and
 * reports/low-stock-summary row against that map by normalized name.
 */
class Saleson_Stock_Sync {

	const CRON_HOOK    = 'saleson_woo_sync_cron';
	const CRON_INTERVAL_KEY = 'saleson_interval';

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'register_cron_schedule' ) );

		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time(), self::CRON_INTERVAL_KEY, self::CRON_HOOK );
		}

		add_action( self::CRON_HOOK, array( __CLASS__, 'run' ) );
	}

	/**
	 * Registers a custom "every N minutes" schedule since WP core has no
	 * built-in interval that matches saleson_cron_interval_minutes (default 15).
	 */
	public static function register_cron_schedule( $schedules ) {
		$minutes = (int) get_option( 'saleson_cron_interval_minutes', 15 );
		if ( $minutes < 1 ) {
			$minutes = 15;
		}

		$schedules[ self::CRON_INTERVAL_KEY ] = array(
			'interval' => $minutes * MINUTE_IN_SECONDS,
			/* translators: %d: number of minutes between syncs */
			'display'  => sprintf( __( 'Every %d minutes (SalesOn sync)', 'saleson-woo-sync' ), $minutes ),
		);

		return $schedules;
	}

	/**
	 * Main cron entry point. Never lets an API failure or unexpected shape
	 * become a PHP fatal - always finishes the log row, even on error.
	 */
	public static function run() {
		$log_id    = Saleson_Logger::start( 'stock_price_pull' );
		$processed = 0;

		try {
			$api = new Saleson_API();

			$name_to_product = self::fetch_id_catalog( $api );
			$rate_list       = self::fetch_paginated( $api, 'reports/rate-list' );
			$low_stock       = self::fetch_paginated( $api, 'reports/low-stock-summary' );

			$low_stock_by_name = array();
			foreach ( $low_stock as $row ) {
				if ( empty( $row['name'] ) ) {
					continue;
				}
				$low_stock_by_name[ self::normalize_name( $row['name'] ) ] = $row;
			}

			global $wpdb;
			$now        = current_time( 'mysql' );
			$cache_table = $wpdb->prefix . 'saleson_stock_cache';

			foreach ( $rate_list as $row ) {
				if ( empty( $row['name'] ) ) {
					continue;
				}
				$norm = self::normalize_name( $row['name'] );

				if ( ! isset( $name_to_product[ $norm ] ) ) {
					// No numeric id resolvable for this row - can't safely
					// cache it (PK is the numeric id). Skip, don't fatal.
					continue;
				}

				$product    = $name_to_product[ $norm ];
				$saleson_id = (int) $product['id'];

				// Prefer the low-stock-summary figure when this row is one
				// of the (small) set of currently-low-stock products, since
				// that report is the more targeted/fresher of the two for
				// stock levels; otherwise fall back to the catalog's own
				// `stock` field from GET /products.
				if ( isset( $low_stock_by_name[ $norm ]['stock'] ) ) {
					$stock = (int) round( (float) $low_stock_by_name[ $norm ]['stock'] );
				} elseif ( isset( $product['stock'] ) ) {
					$stock = (int) round( (float) $product['stock'] );
				} else {
					$stock = 0;
				}

				$product_code = '';
				if ( ! empty( $row['product_code'] ) ) {
					$product_code = $row['product_code'];
				} elseif ( ! empty( $product['product_code'] ) ) {
					$product_code = $product['product_code'];
				}

				$group_name = isset( $product['group_id'] ) && $product['group_id'] !== '' ? (string) $product['group_id'] : null;
				$brand      = isset( $product['brand_id'] ) && $product['brand_id'] !== '' ? (string) $product['brand_id'] : null;

				$wpdb->replace(
					$cache_table,
					array(
						'saleson_product_id' => $saleson_id,
						'name'               => sanitize_text_field( $row['name'] ),
						'product_code'       => $product_code !== '' ? sanitize_text_field( $product_code ) : null,
						'group_name'         => $group_name ? sanitize_text_field( $group_name ) : null,
						'brand'              => $brand ? sanitize_text_field( $brand ) : null,
						'stock'              => $stock,
						'last_synced_at'     => $now,
					),
					array( '%d', '%s', '%s', '%s', '%s', '%d', '%s' )
				);

				self::ensure_product_map_row( $saleson_id );

				$processed++;
			}

			// Same cadence: price tiers, logged as its own run.
			Saleson_Price_Sync_Pull::pull_all_tiers();

			// Push the freshly-cached stock/price onto Woo products that are
			// already matched, so the storefront reflects this run immediately.
			self::push_to_matched_woo_products();

			Saleson_Logger::finish( $log_id, $processed, 0, null );
		} catch ( \Throwable $e ) {
			Saleson_Logger::finish( $log_id, $processed, 1, $e->getMessage() );
		}
	}

	/**
	 * GET products?with_unit=false - single call, whole catalog, has the
	 * real numeric SalesOn product id. Returns a normalized-name => product
	 * array map.
	 */
	private static function fetch_id_catalog( Saleson_API $api ) {
		$result = $api->get( 'products', array( 'with_unit' => 'false' ) );

		if ( ! $result['ok'] || empty( $result['data']['products'] ) || ! is_array( $result['data']['products'] ) ) {
			throw new \RuntimeException( 'Failed to fetch SalesOn product catalog: ' . ( $result['error'] ? $result['error'] : 'unknown error' ) );
		}

		$map = array();
		foreach ( $result['data']['products'] as $p ) {
			if ( empty( $p['id'] ) || empty( $p['name'] ) ) {
				continue;
			}
			$map[ self::normalize_name( $p['name'] ) ] = $p;
		}

		return $map;
	}

	/**
	 * Cursor-paginated pull for reports/rate-list and
	 * reports/low-stock-summary (page_size + opaque cursor, next page via
	 * page_info.next_cursor - confirmed shape in Phase 0).
	 */
	private static function fetch_paginated( Saleson_API $api, $path ) {
		$rows   = array();
		$cursor = null;
		$page   = 0;

		do {
			$params = array( 'page_size' => 100 );
			if ( $cursor ) {
				$params['cursor'] = $cursor;
			}

			$result = $api->get( $path, $params );
			if ( ! $result['ok'] ) {
				throw new \RuntimeException( "Failed to fetch {$path}: " . ( $result['error'] ? $result['error'] : 'unknown error' ) );
			}

			$data  = is_array( $result['data'] ) ? $result['data'] : array();
			$batch = isset( $data['reports'] ) && is_array( $data['reports'] ) ? $data['reports'] : array();
			$rows  = array_merge( $rows, $batch );

			$cursor = isset( $data['page_info']['next_cursor'] ) ? $data['page_info']['next_cursor'] : null;
			$page++;
		} while ( $cursor && ! empty( $batch ) && $page < 50 ); // safety valve

		return $rows;
	}

	private static function normalize_name( $name ) {
		$name = strtolower( trim( (string) $name ) );
		$name = preg_replace( '/[^a-z0-9\s]/', '', $name );
		$name = preg_replace( '/\s+/', ' ', $name );
		return trim( (string) $name );
	}

	/**
	 * Insert-if-missing only. Never touches mapping_status/woo_product_id
	 * on a row that already exists - the Matcher screen owns that data once set.
	 */
	private static function ensure_product_map_row( $saleson_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'saleson_product_map';

		$exists = $wpdb->get_var(
			$wpdb->prepare( "SELECT saleson_product_id FROM {$table} WHERE saleson_product_id = %d", $saleson_id )
		);

		if ( $exists ) {
			return;
		}

		$wpdb->insert(
			$table,
			array(
				'saleson_product_id' => $saleson_id,
				'woo_product_id'     => null,
				'mapping_status'     => 'unmatched',
				'confidence'         => null,
				'source'             => 'stock_sync',
				'mapped_at'          => null,
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * For every already-matched product_map row, push the cached stock and
	 * the RETAIL CUSTOMER (price list 1471) rate onto the linked WooCommerce
	 * product. Never fatals if WooCommerce isn't active or a product 404s.
	 */
	private static function push_to_matched_woo_products() {
		if ( ! function_exists( 'wc_update_product_stock' ) || ! function_exists( 'wc_get_product' ) ) {
			return;
		}

		global $wpdb;
		$map_table   = $wpdb->prefix . 'saleson_product_map';
		$cache_table = $wpdb->prefix . 'saleson_stock_cache';
		$tiers_table = $wpdb->prefix . 'saleson_price_tiers';

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT m.woo_product_id, c.stock, t.rate AS retail_rate
				 FROM {$map_table} m
				 INNER JOIN {$cache_table} c ON c.saleson_product_id = m.saleson_product_id
				 LEFT JOIN {$tiers_table} t ON t.saleson_product_id = m.saleson_product_id AND t.price_list_id = %d
				 WHERE m.mapping_status = 'matched' AND m.woo_product_id IS NOT NULL",
				Saleson_API::PRICE_LIST_RETAIL
			),
			ARRAY_A
		);

		if ( empty( $rows ) ) {
			return;
		}

		foreach ( $rows as $row ) {
			$woo_id = (int) $row['woo_product_id'];
			if ( ! $woo_id ) {
				continue;
			}

			$product = wc_get_product( $woo_id );
			if ( ! $product ) {
				continue;
			}

			wc_update_product_stock( $product, (int) $row['stock'], 'set' );

			if ( isset( $row['retail_rate'] ) && $row['retail_rate'] !== null && $row['retail_rate'] !== '' ) {
				$product = wc_get_product( $woo_id ); // reload post-stock-update
				if ( $product ) {
					$product->set_regular_price( (string) $row['retail_rate'] );
					$product->save();
				}
			}
		}
	}
}
