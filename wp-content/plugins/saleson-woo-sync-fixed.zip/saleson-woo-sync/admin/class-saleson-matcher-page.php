<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Human-in-the-loop reconciliation UI for wp_saleson_product_map, seeded from the
 * Phase 0 spreadsheet via Saleson_Map_Importer.
 *
 * Four tabs, one per mapping_status:
 *  - matched   (183 seed rows) - Confirm (no-op) / Reject (back to unmatched, clears woo id)
 *  - unmatched (715 seed rows) - filterable by category, "Create as product" per row only
 *                                (Option B: on-demand, never automatic/bulk creation)
 *  - orphan    (54 seed rows)  - read-only reference list (Woo products with no SalesOn id)
 *  - ignored   (196 seed rows) - read-only reference list (blank placeholder Woo products)
 */
class Saleson_Matcher_Page {

	const PAGE_SLUG  = 'saleson-matcher';
	const PER_PAGE   = 25;

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_post_saleson_run_map_import', array( __CLASS__, 'handle_run_import' ) );
		add_action( 'admin_post_saleson_matcher_confirm', array( __CLASS__, 'handle_confirm' ) );
		add_action( 'admin_post_saleson_matcher_reject', array( __CLASS__, 'handle_reject' ) );
		add_action( 'admin_post_saleson_matcher_create_product', array( __CLASS__, 'handle_create_product' ) );
		add_action( 'admin_notices', array( __CLASS__, 'render_admin_notices' ) );
	}

	public static function register_menu() {
		if ( class_exists( 'WooCommerce' ) ) {
			add_submenu_page(
				'woocommerce',
				__( 'SalesOn Matcher', 'saleson-woo-sync' ),
				__( 'SalesOn Matcher', 'saleson-woo-sync' ),
				'manage_options',
				self::PAGE_SLUG,
				array( __CLASS__, 'render_page' )
			);
		} else {
			add_menu_page(
				__( 'SalesOn Matcher', 'saleson-woo-sync' ),
				__( 'SalesOn Matcher', 'saleson-woo-sync' ),
				'manage_options',
				self::PAGE_SLUG,
				array( __CLASS__, 'render_page' ),
				'dashicons-randomize'
			);
		}
	}

	// --- Action handlers --------------------------------------------------------

	public static function handle_run_import() {
		check_admin_referer( 'saleson_run_map_import' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'saleson-woo-sync' ) );
		}

		$result = Saleson_Map_Importer::import_from_spreadsheet();

		set_transient( 'saleson_matcher_notice_' . get_current_user_id(), $result, 60 );

		self::redirect_back( array( 'tab' => 'matched' ) );
	}

	public static function handle_confirm() {
		check_admin_referer( 'saleson_matcher_row' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'saleson-woo-sync' ) );
		}
		// Confirm is a no-op: the row is already 'matched'. Nothing to persist -
		// it exists purely so the reviewer has an explicit affirmative action.
		self::redirect_back( array( 'tab' => 'matched' ) );
	}

	public static function handle_reject() {
		check_admin_referer( 'saleson_matcher_row' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'saleson-woo-sync' ) );
		}

		$saleson_id = isset( $_POST['saleson_product_id'] ) ? absint( $_POST['saleson_product_id'] ) : 0;
		if ( $saleson_id ) {
			global $wpdb;
			$wpdb->update(
				$wpdb->prefix . 'saleson_product_map',
				array(
					'mapping_status'  => 'unmatched',
					'woo_product_id' => null,
				),
				array( 'saleson_product_id' => $saleson_id )
			);
		}

		self::redirect_back( array( 'tab' => 'matched' ) );
	}

	public static function handle_create_product() {
		check_admin_referer( 'saleson_matcher_row' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'saleson-woo-sync' ) );
		}

		$saleson_id = isset( $_POST['saleson_product_id'] ) ? absint( $_POST['saleson_product_id'] ) : 0;

		if ( $saleson_id && function_exists( 'wc_get_product' ) ) {
			self::create_product_for( $saleson_id );
		}

		self::redirect_back( array( 'tab' => 'unmatched' ) );
	}

	/**
	 * Creates a single draft WooCommerce product for one 'unmatched' mapping row.
	 * On-demand only - called for exactly the one row the reviewer clicked, never
	 * in bulk or automatically.
	 */
	private static function create_product_for( $saleson_id ) {
		global $wpdb;
		$map_table = $wpdb->prefix . 'saleson_product_map';

		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$map_table} WHERE saleson_product_id = %d AND mapping_status = 'unmatched'", $saleson_id )
		);
		if ( ! $row ) {
			return;
		}

		$name  = $row->saleson_name;
		$stock = is_numeric( $row->stock ) ? (int) $row->stock : null;
		$sku   = '';
		$price = null;

		$cache_table = $wpdb->prefix . 'saleson_stock_cache';
		if ( self::table_exists( $cache_table ) ) {
			$cache = $wpdb->get_row(
				$wpdb->prepare( "SELECT * FROM {$cache_table} WHERE saleson_product_id = %d", $saleson_id )
			);
			if ( $cache ) {
				if ( ! empty( $cache->name ) ) {
					$name = $cache->name;
				}
				if ( ! empty( $cache->product_code ) ) {
					$sku = $cache->product_code;
				}
				if ( null === $stock && isset( $cache->stock ) ) {
					$stock = (int) $cache->stock;
				}
			}
		}

		$price_table = $wpdb->prefix . 'saleson_price_tiers';
		if ( self::table_exists( $price_table ) && class_exists( 'Saleson_API' ) ) {
			$tier = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT rate FROM {$price_table} WHERE saleson_product_id = %d AND price_list_id = %d",
					$saleson_id,
					Saleson_API::PRICE_LIST_RETAIL
				)
			);
			if ( $tier && null !== $tier->rate ) {
				$price = $tier->rate;
			}
		}

		if ( empty( $name ) ) {
			$name = sprintf( 'SalesOn #%d', $saleson_id );
		}

		$product = new WC_Product_Simple();
		$product->set_name( $name );
		$product->set_status( 'draft' );
		if ( $sku ) {
			$product->set_sku( $sku );
		}
		if ( null !== $price ) {
			$product->set_regular_price( $price );
		}
		if ( null !== $stock ) {
			$product->set_manage_stock( true );
			$product->set_stock_quantity( $stock );
			$product->set_stock_status( $stock > 0 ? 'instock' : 'outofstock' );
		}

		$new_id = $product->save();

		if ( ! $new_id || is_wp_error( $new_id ) ) {
			return;
		}

		if ( ! empty( $row->category ) ) {
			self::maybe_assign_category( $new_id, $row->category );
		}

		$wpdb->update(
			$map_table,
			array(
				'mapping_status'  => 'matched',
				'woo_product_id' => $new_id,
				'source'          => 'manual_create',
				'mapped_at'       => current_time( 'mysql' ),
			),
			array( 'saleson_product_id' => $saleson_id )
		);
	}

	private static function maybe_assign_category( $product_id, $category_name ) {
		if ( ! taxonomy_exists( 'product_cat' ) ) {
			return;
		}
		$term = term_exists( $category_name, 'product_cat' );
		if ( ! $term ) {
			$term = wp_insert_term( $category_name, 'product_cat' );
		}
		if ( ! is_wp_error( $term ) && isset( $term['term_id'] ) ) {
			wp_set_object_terms( $product_id, (int) $term['term_id'], 'product_cat' );
		}
	}

	private static function table_exists( $table ) {
		global $wpdb;
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		return $found === $table;
	}

	private static function redirect_back( $extra_args = array() ) {
		$url = add_query_arg(
			array_merge( array( 'page' => self::PAGE_SLUG ), $extra_args ),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $url );
		exit;
	}

	public static function render_admin_notices() {
		$screen = get_current_screen();
		if ( ! $screen || false === strpos( $screen->id, self::PAGE_SLUG ) ) {
			return;
		}

		$key    = 'saleson_matcher_notice_' . get_current_user_id();
		$result = get_transient( $key );
		if ( false === $result ) {
			return;
		}
		delete_transient( $key );

		if ( ! empty( $result['ok'] ) ) {
			$counts  = isset( $result['counts'] ) ? $result['counts'] : array();
			$summary = array();
			foreach ( $counts as $status => $c ) {
				$summary[] = sprintf( '%s: %d inserted, %d refreshed', $status, $c['inserted'], $c['refreshed'] );
			}
			printf(
				'<div class="notice notice-success is-dismissible"><p>%s %s</p></div>',
				esc_html__( 'Spreadsheet import complete.', 'saleson-woo-sync' ),
				esc_html( implode( ' | ', $summary ) )
			);
		} else {
			printf(
				'<div class="notice notice-error is-dismissible"><p>%s %s</p></div>',
				esc_html__( 'Spreadsheet import failed:', 'saleson-woo-sync' ),
				esc_html( isset( $result['error'] ) ? $result['error'] : __( 'Unknown error', 'saleson-woo-sync' ) )
			);
		}
	}

	// --- Rendering --------------------------------------------------------------

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'matched';
		if ( ! in_array( $tab, array( 'matched', 'unmatched', 'orphan', 'ignored' ), true ) ) {
			$tab = 'matched';
		}

		$tabs = array(
			'matched'   => __( 'Matched', 'saleson-woo-sync' ),
			'unmatched' => __( 'Unmatched (SalesOn only)', 'saleson-woo-sync' ),
			'orphan'    => __( 'Orphans (Woo only)', 'saleson-woo-sync' ),
			'ignored'   => __( 'Ignored (blank placeholders)', 'saleson-woo-sync' ),
		);
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'SalesOn Product Matcher', 'saleson-woo-sync' ); ?></h1>

			<p><?php esc_html_e( 'Reconciles SalesOn ERP products against this WooCommerce catalog, seeded from the Phase 0 spreadsheet review.', 'saleson-woo-sync' ); ?></p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:1em;">
				<?php wp_nonce_field( 'saleson_run_map_import' ); ?>
				<input type="hidden" name="action" value="saleson_run_map_import" />
				<?php submit_button( __( 'Run / Re-run Spreadsheet Import', 'saleson-woo-sync' ), 'secondary', 'submit', false ); ?>
				<p class="description"><?php esc_html_e( 'Safe to run more than once - existing rows keep their current status; only new rows and descriptive details are added.', 'saleson-woo-sync' ); ?></p>
			</form>

			<h2 class="nav-tab-wrapper">
				<?php foreach ( $tabs as $slug => $label ) : ?>
					<a href="<?php echo esc_url( add_query_arg( array( 'page' => self::PAGE_SLUG, 'tab' => $slug ), admin_url( 'admin.php' ) ) ); ?>"
						class="nav-tab <?php echo $tab === $slug ? 'nav-tab-active' : ''; ?>">
						<?php echo esc_html( $label ); ?>
					</a>
				<?php endforeach; ?>
			</h2>

			<?php
			switch ( $tab ) {
				case 'unmatched':
					self::render_unmatched_tab();
					break;
				case 'orphan':
					self::render_readonly_tab( 'orphan', array(
						'woo_name' => __( 'Woo Name', 'saleson-woo-sync' ),
						'sku'      => __( 'SKU', 'saleson-woo-sync' ),
						'category' => __( 'Category', 'saleson-woo-sync' ),
					) );
					break;
				case 'ignored':
					self::render_readonly_tab( 'ignored', array(
						'sku'      => __( 'SKU', 'saleson-woo-sync' ),
						'category' => __( 'Category', 'saleson-woo-sync' ),
						'notes'    => __( 'Notes', 'saleson-woo-sync' ),
					) );
					break;
				case 'matched':
				default:
					self::render_matched_tab();
					break;
			}
			?>
		</div>
		<?php
	}

	private static function get_paged() {
		return isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
	}

	private static function render_pagination( $total, $paged, $extra_args = array() ) {
		$total_pages = (int) ceil( $total / self::PER_PAGE );
		if ( $total_pages <= 1 ) {
			return;
		}
		$base = add_query_arg( array_merge( array( 'page' => self::PAGE_SLUG ), $extra_args, array( 'paged' => '%#%' ) ), admin_url( 'admin.php' ) );
		echo '<div class="tablenav"><div class="tablenav-pages">';
		echo wp_kses_post( paginate_links( array(
			'base'      => $base,
			'format'    => '',
			'current'   => $paged,
			'total'     => $total_pages,
			'prev_text' => __( '&laquo; Previous', 'saleson-woo-sync' ),
			'next_text' => __( 'Next &raquo;', 'saleson-woo-sync' ),
		) ) );
		echo '</div></div>';
	}

	private static function render_matched_tab() {
		global $wpdb;
		$table = $wpdb->prefix . 'saleson_product_map';
		$paged = self::get_paged();
		$offset = ( $paged - 1 ) * self::PER_PAGE;

		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE mapping_status = 'matched'" );
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE mapping_status = 'matched' ORDER BY saleson_product_id ASC LIMIT %d OFFSET %d",
				self::PER_PAGE,
				$offset
			)
		);

		printf( '<p>%s</p>', esc_html( sprintf( __( '%d matched rows total.', 'saleson-woo-sync' ), $total ) ) );
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'SalesOn ID', 'saleson-woo-sync' ); ?></th>
					<th><?php esc_html_e( 'SalesOn Name', 'saleson-woo-sync' ); ?></th>
					<th><?php esc_html_e( 'Woo ID', 'saleson-woo-sync' ); ?></th>
					<th><?php esc_html_e( 'Woo Name', 'saleson-woo-sync' ); ?></th>
					<th><?php esc_html_e( 'Confidence', 'saleson-woo-sync' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'saleson-woo-sync' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $rows ) ) : ?>
				<tr><td colspan="6"><?php esc_html_e( 'No matched rows yet - run the import above.', 'saleson-woo-sync' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $rows as $row ) : ?>
				<tr>
					<td><?php echo esc_html( $row->saleson_product_id ); ?></td>
					<td><?php echo esc_html( $row->saleson_name ); ?></td>
					<td><?php echo esc_html( $row->woo_product_id ); ?></td>
					<td><?php echo esc_html( $row->woo_name ); ?></td>
					<td><?php echo esc_html( $row->confidence ); ?></td>
					<td>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
							<?php wp_nonce_field( 'saleson_matcher_row' ); ?>
							<input type="hidden" name="action" value="saleson_matcher_confirm" />
							<input type="hidden" name="saleson_product_id" value="<?php echo esc_attr( $row->saleson_product_id ); ?>" />
							<?php submit_button( __( 'Confirm', 'saleson-woo-sync' ), 'primary small', 'submit', false ); ?>
						</form>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
							<?php wp_nonce_field( 'saleson_matcher_row' ); ?>
							<input type="hidden" name="action" value="saleson_matcher_reject" />
							<input type="hidden" name="saleson_product_id" value="<?php echo esc_attr( $row->saleson_product_id ); ?>" />
							<?php submit_button( __( 'Reject', 'saleson-woo-sync' ), 'delete small', 'submit', false ); ?>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		self::render_pagination( $total, $paged, array( 'tab' => 'matched' ) );
	}

	private static function render_unmatched_tab() {
		global $wpdb;
		$table = $wpdb->prefix . 'saleson_product_map';
		$paged = self::get_paged();
		$offset = ( $paged - 1 ) * self::PER_PAGE;

		$category = isset( $_GET['category'] ) ? sanitize_text_field( wp_unslash( $_GET['category'] ) ) : '';

		$categories = $wpdb->get_col(
			"SELECT DISTINCT category FROM {$table} WHERE mapping_status = 'unmatched' AND category IS NOT NULL AND category != '' ORDER BY category ASC"
		);

		$where  = "mapping_status = 'unmatched'";
		$params = array();
		if ( '' !== $category ) {
			$where   .= ' AND category = %s';
			$params[] = $category;
		}

		$total_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where}";
		$total     = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $total_sql, $params ) ) : $wpdb->get_var( $total_sql ) );

		$rows_sql    = "SELECT * FROM {$table} WHERE {$where} ORDER BY category ASC, saleson_name ASC LIMIT %d OFFSET %d";
		$rows_params = array_merge( $params, array( self::PER_PAGE, $offset ) );
		$rows        = $wpdb->get_results( $wpdb->prepare( $rows_sql, $rows_params ) );
		?>
		<form method="get" style="margin:1em 0;">
			<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>" />
			<input type="hidden" name="tab" value="unmatched" />
			<label for="saleson-category-filter"><?php esc_html_e( 'Filter by category:', 'saleson-woo-sync' ); ?></label>
			<select name="category" id="saleson-category-filter" onchange="this.form.submit()">
				<option value=""><?php esc_html_e( 'All categories', 'saleson-woo-sync' ); ?></option>
				<?php foreach ( $categories as $cat ) : ?>
					<option value="<?php echo esc_attr( $cat ); ?>" <?php selected( $category, $cat ); ?>><?php echo esc_html( $cat ); ?></option>
				<?php endforeach; ?>
			</select>
			<noscript><?php submit_button( __( 'Filter', 'saleson-woo-sync' ), 'secondary', 'submit', false ); ?></noscript>
		</form>

		<p><?php echo esc_html( sprintf( __( '%d unmatched rows total.', 'saleson-woo-sync' ), $total ) ); ?></p>

		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'SalesOn ID', 'saleson-woo-sync' ); ?></th>
					<th><?php esc_html_e( 'Name', 'saleson-woo-sync' ); ?></th>
					<th><?php esc_html_e( 'Category', 'saleson-woo-sync' ); ?></th>
					<th><?php esc_html_e( 'Stock', 'saleson-woo-sync' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'saleson-woo-sync' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $rows ) ) : ?>
				<tr><td colspan="5"><?php esc_html_e( 'No unmatched rows.', 'saleson-woo-sync' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $rows as $row ) : ?>
				<tr>
					<td><?php echo esc_html( $row->saleson_product_id ); ?></td>
					<td><?php echo esc_html( $row->saleson_name ); ?></td>
					<td><?php echo esc_html( $row->category ); ?></td>
					<td><?php echo esc_html( $row->stock ); ?></td>
					<td>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Create a new draft WooCommerce product for this single item?', 'saleson-woo-sync' ) ); ?>');">
							<?php wp_nonce_field( 'saleson_matcher_row' ); ?>
							<input type="hidden" name="action" value="saleson_matcher_create_product" />
							<input type="hidden" name="saleson_product_id" value="<?php echo esc_attr( $row->saleson_product_id ); ?>" />
							<?php submit_button( __( 'Create as product', 'saleson-woo-sync' ), 'primary small', 'submit', false ); ?>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		self::render_pagination( $total, $paged, array( 'tab' => 'unmatched', 'category' => $category ) );
	}

	/**
	 * Read-only reference list for 'orphan' and 'ignored' rows - both are Woo-only
	 * (no real SalesOn id, keyed by a synthetic id - see Saleson_Map_Importer)
	 * and require no reconciliation action, just visibility.
	 */
	private static function render_readonly_tab( $status, $extra_columns ) {
		global $wpdb;
		$table  = $wpdb->prefix . 'saleson_product_map';
		$paged  = self::get_paged();
		$offset = ( $paged - 1 ) * self::PER_PAGE;

		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE mapping_status = %s", $status ) );
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE mapping_status = %s ORDER BY woo_product_id ASC LIMIT %d OFFSET %d",
				$status,
				self::PER_PAGE,
				$offset
			)
		);

		printf( '<p>%s</p>', esc_html( sprintf( __( '%d rows total.', 'saleson-woo-sync' ), $total ) ) );
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Woo ID', 'saleson-woo-sync' ); ?></th>
					<?php foreach ( $extra_columns as $label ) : ?>
						<th><?php echo esc_html( $label ); ?></th>
					<?php endforeach; ?>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $rows ) ) : ?>
				<tr><td colspan="<?php echo esc_attr( count( $extra_columns ) + 1 ); ?>"><?php esc_html_e( 'No rows.', 'saleson-woo-sync' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $rows as $row ) : ?>
				<tr>
					<td><?php echo esc_html( $row->woo_product_id ); ?></td>
					<?php foreach ( array_keys( $extra_columns ) as $col ) : ?>
						<td><?php echo esc_html( $row->$col ); ?></td>
					<?php endforeach; ?>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		self::render_pagination( $total, $paged, array( 'tab' => $status ) );
	}
}
